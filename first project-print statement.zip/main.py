#Write your code below thi

print("Day 1 - Python print function")
print("the function is declared like this")
print("print('what to print')")









