# 🚨 Don't change the code below 👇
print("Welcome to the Love Calculator!")
name1 = input("What is your name? \n")
name2 = input("What is their name? \n")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
#true
love1=(name1.lower())
love2=(name2.lower())
t1=(love1.count("t"))
r1=(love1.count("r"))
u1=(love1.count("u"))
e1=(love1.count("e"))
t2=(love2.count("t"))
r2=(love2.count("r"))
u2=(love2.count("u"))
e2=(love2.count("e"))
#love
l1=(love1.count("l"))
o1=(love1.count("o"))
v1=(love1.count("v"))
e3=(love1.count("e"))
l2=(love2.count("l"))
o2=(love2.count("o"))
v2=(love2.count("v"))
e4=(love2.count("e"))
result_true= t1+r1+u1+e1+t2+r2+u2+e2
result_love= l1+o1+v1+e3+l2+o2+v2+e4
#print(result_true)
#print(result_love)
scores= str(result_true) + str(result_love)
score=(int(scores))
#print(score )

if int(score) < 10 or score > 90:
    print(f"Your score is {score}, you go together like coke and mentos.")
elif int(score) > 40 and score < 50:
  print(f"Your score is {score}, you are alright together.")      
else:
 print(f"Your score is {score}.") 









