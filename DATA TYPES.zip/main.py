
two_digit_number = input("Type a two digit number: ")



print(type(two_digit_number))
print(int(two_digit_number[0]))
print(int(two_digit_number[1]))
first_num = two_digit_number[0]
second_num =two_digit_number[1]
result= int(first_num) + int(second_num)
print(result)
