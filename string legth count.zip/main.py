#Write your code below this line
#input("please anwser my question ")
print(len(input("What is your name?")))









