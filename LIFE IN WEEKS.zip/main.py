 # a program using maths and f-Strings that tells us how many days, weeks, months we have left if we live until 90 years old.
age = input("What is your current age?")



print(int(age))




years=int(90)-int(age)
print(int(years))

days=int(90) * int(365) - int(age) *int(365)
print(int(days))

months= int(90) * int(12) - int(age) *int(12)
print(int(months))

weeks= int(90)* int(52) - int(age)* int(52)
print(int(weeks))

print(f"You have {days}, {weeks} weeks, and {months} months left")










